./dfs DFS1 10001 >/dev/null &
./dfs DFS2 10002 >/dev/null &
./dfs DFS3 10003 >/dev/null &
./dfs DFS4 10004 >/dev/null &