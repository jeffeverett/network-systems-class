rm -r DFS1/*
rm -r DFS2/*
rm -r DFS3/*
rm -r DFS4/*